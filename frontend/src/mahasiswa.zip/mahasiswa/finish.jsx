import { useRef } from 'react';
import { useReactToPrint } from 'react-to-print';
import { useCV } from './CVContext';
import Preview from './Preview';

export default function FinishForm() {
    const { state, prevStep, setStep, updateContact } = useCV();
    const { contact, experience, education, skills, about } = state;
    const previewRef = useRef(null);

    const handlePrint = useReactToPrint({
        contentRef: previewRef,
        documentTitle: `CV_${contact.firstName}_${contact.lastName}`.replace(/\s+/g, '_') || 'My_CV',
        pageStyle: `
            @page {
                size: 215.9mm 330mm;
                margin: 0;
            }
            @media print {
                html, body {
                    width: 215.9mm;
                    height: 330mm;
                    margin: 0;
                    padding: 0;
                }
            }
        `,
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        updateContact({ [name]: value });
    };

    // Summary counts
    const experienceCount = experience.length;
    const educationCount = education.length;
    const skillsCount = skills.length;
    const hasSummary = about.summary.trim().length > 0;
    const hasContact = contact.firstName || contact.lastName || contact.email;

    return (
        <div className="space-y-6">
            {/* Header */}
            <div>
                <h1 className="text-2xl font-bold text-gray-800">
                    <span className="text-sky-500">🎉 Great job!</span> Your CV is ready
                </h1>
                <p className="text-gray-500 mt-1">
                    Review your CV, add optional details, and download it as a PDF.
                </p>
            </div>

            {/* Optional Personal Details */}
            <div className="bg-gray-50 p-4 rounded-xl border border-gray-200">
                <h2 className="text-lg font-semibold text-gray-800 mb-4">
                    Optional Personal Details
                </h2>
                <p className="text-sm text-gray-500 mb-4">
                    These fields are optional and will be shown in the CV sidebar.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Nationality */}
                    <div>
                        <label htmlFor="nationality" className="block text-sm font-medium text-gray-700 mb-1">
                            Nationality
                        </label>
                        <input
                            type="text"
                            id="nationality"
                            name="nationality"
                            value={contact.nationality}
                            onChange={handleChange}
                            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500 outline-none transition-all"
                            placeholder="Indonesia"
                        />
                    </div>

                    {/* Visa Status */}
                    <div>
                        <label htmlFor="visaStatus" className="block text-sm font-medium text-gray-700 mb-1">
                            Visa Status
                        </label>
                        <select
                            id="visaStatus"
                            name="visaStatus"
                            value={contact.visaStatus}
                            onChange={handleChange}
                            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500 outline-none transition-all"
                        >
                            <option value="">Select...</option>
                            <option value="Citizen">Citizen</option>
                            <option value="Permanent Resident">Permanent Resident</option>
                            <option value="Work Visa">Work Visa</option>
                            <option value="Student Visa">Student Visa</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    {/* Marital Status */}
                    <div>
                        <label htmlFor="maritalStatus" className="block text-sm font-medium text-gray-700 mb-1">
                            Marital Status
                        </label>
                        <select
                            id="maritalStatus"
                            name="maritalStatus"
                            value={contact.maritalStatus}
                            onChange={handleChange}
                            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500 outline-none transition-all"
                        >
                            <option value="">Select...</option>
                            <option value="Single">Single / Lajang</option>
                            <option value="Married">Married / Menikah</option>
                            <option value="Divorced">Divorced</option>
                            <option value="Widowed">Widowed</option>
                        </select>
                    </div>
                </div>
            </div>

            {/* Summary Card */}
            <div className="bg-gradient-to-r from-sky-50 to-blue-50 p-6 rounded-xl border border-sky-100">
                <h2 className="text-lg font-semibold text-gray-800 mb-4">CV Summary</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="bg-white p-4 rounded-lg shadow-sm">
                        <div className="text-2xl font-bold text-sky-500">
                            {hasContact ? '✓' : '—'}
                        </div>
                        <div className="text-sm text-gray-600">Contact Info</div>
                    </div>
                    <div className="bg-white p-4 rounded-lg shadow-sm">
                        <div className="text-2xl font-bold text-sky-500">{experienceCount}</div>
                        <div className="text-sm text-gray-600">Experience(s)</div>
                    </div>
                    <div className="bg-white p-4 rounded-lg shadow-sm">
                        <div className="text-2xl font-bold text-sky-500">{educationCount}</div>
                        <div className="text-sm text-gray-600">Education(s)</div>
                    </div>
                    <div className="bg-white p-4 rounded-lg shadow-sm">
                        <div className="text-2xl font-bold text-sky-500">{skillsCount}</div>
                        <div className="text-sm text-gray-600">Skill(s)</div>
                    </div>
                    <div className="bg-white p-4 rounded-lg shadow-sm">
                        <div className="text-2xl font-bold text-sky-500">
                            {hasSummary ? '✓' : '—'}
                        </div>
                        <div className="text-sm text-gray-600">Summary</div>
                    </div>
                </div>
            </div>

            {/* Quick Edit Links */}
            <div className="flex flex-wrap gap-2">
                <span className="text-sm text-gray-500">Quick edit:</span>
                <button
                    onClick={() => setStep(0)}
                    className="text-sm text-sky-500 hover:text-sky-600 underline"
                >
                    Contact
                </button>
                <button
                    onClick={() => setStep(1)}
                    className="text-sm text-sky-500 hover:text-sky-600 underline"
                >
                    Experience
                </button>
                <button
                    onClick={() => setStep(2)}
                    className="text-sm text-sky-500 hover:text-sky-600 underline"
                >
                    Education
                </button>
                <button
                    onClick={() => setStep(3)}
                    className="text-sm text-sky-500 hover:text-sky-600 underline"
                >
                    Skills
                </button>
                <button
                    onClick={() => setStep(4)}
                    className="text-sm text-sky-500 hover:text-sky-600 underline"
                >
                    About
                </button>
            </div>

            {/* Download Button */}
            <div className="pt-4">
                <button
                    onClick={handlePrint}
                    className="w-full flex items-center justify-center gap-3 bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 text-white px-8 py-4 rounded-xl font-semibold text-lg shadow-lg hover:shadow-xl transition-all duration-200"
                >
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-6 w-6"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth={2}
                    >
                        <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                        />
                    </svg>
                    Download CV as PDF
                </button>
            </div>

            {/* Tip */}
            <p className="text-sm text-gray-400 text-center">
                💡 Tip: The PDF will be generated from the preview on the right. Make sure it looks good!
            </p>

            {/* Navigation */}
            <div className="flex justify-start pt-4">
                <button
                    onClick={prevStep}
                    className="flex items-center gap-2 text-gray-600 hover:text-gray-800 font-medium transition-colors"
                >
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5"
                        viewBox="0 0 20 20"
                        fill="currentColor"
                    >
                        <path
                            fillRule="evenodd"
                            d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z"
                            clipRule="evenodd"
                        />
                    </svg>
                    Back to About
                </button>
            </div>

            {/* Hidden Preview for Print */}
            <div className="hidden">
                <Preview ref={previewRef} forPrint={true} />
            </div>
        </div>
    );
}
